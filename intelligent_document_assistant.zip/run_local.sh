#!/bin/bash
streamlit run app/app.py
