
QA_PROMPT = """You are a helpful assistant.
Answer the QUESTION strictly using the CONTEXT. If the answer isn't in the context, say "I don't know".

CONTEXT:
{context}

QUESTION:
{question}

Answer (cite facts from the context):"""
